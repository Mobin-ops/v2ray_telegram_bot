import os

API_KEY = os.getenv("API_KEY")
BOT_TOKEN = os.getenv("BOT_TOKEN")
API_BASE = "https://robot.wizardxray.shop/newbot/api/v1/"
