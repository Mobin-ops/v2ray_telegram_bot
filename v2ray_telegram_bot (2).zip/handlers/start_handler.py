def start(update, context):
    update.message.reply_text(
        "سلام 👋\nبه ربات خرید VPN خوش اومدی.\nبرای خرید سرویس دستور /buy رو بزن."
    )
